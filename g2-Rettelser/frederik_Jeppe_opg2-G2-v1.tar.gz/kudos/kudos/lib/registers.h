/*
 * Register name definitions for assembler code.
 */

#ifndef LIB_REGISTERS_H
#define LIB_REGISTERS_H

#include "mips32/registers.h"

#endif
