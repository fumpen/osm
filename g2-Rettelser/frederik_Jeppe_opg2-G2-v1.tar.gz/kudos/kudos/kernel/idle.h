/*
 * The wait loop for the idle thread (TID 0).
 */

#ifndef KUDOS_KERNEL_IDLE_H
#define KUDOS_KERNEL_IDLE_H

void _idle_thread_wait_loop(void);

#endif /* KUDOS_KERNEL_IDLE_H */
