/*
 * Exception Handling
 */

#ifndef __EXCEPTIONS_H__
#define __EXCEPTIONS_H__

//Setup Exceptions
void exception_init();

#endif
