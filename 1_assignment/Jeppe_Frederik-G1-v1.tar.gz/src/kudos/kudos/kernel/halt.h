/*
 * Halt the system
 */

#ifndef KUDOS_KERNEL_HALT_H
#define KUDOS_KERNEL_HALT_H

void halt_kernel(void);

#endif /* KUDOS_KERNEL_HALT_H */
